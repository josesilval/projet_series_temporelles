#### import ####
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import warnings
## statsmodels ##
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.arima_process import ArmaProcess
import statsmodels

#### robust fit ####
def robust_arma(series, p, q):
    with warnings.catch_warnings(record=True) as w:
        arima = ARIMA(
                series,
                order=(p,0,q)
            )
        arima_fit = arima.fit()
        for warn in w:
            if warn.category == statsmodels.tools.sm_exceptions.ConvergenceWarning:
                return None
    return arima_fit

#### p values table ####
def get_tables(series, max_p, max_q):
    parameters = []
    pvalues_list = []
    aic_values = []
    bic_values = []
    for p in range(max_p):
        for q in range(max_q):
            fit = robust_arma(series, p, q)
            if fit:
                pvalues = fit.pvalues
                parameters.append(f'{p},{q}')
                pvalues_list.append(pvalues)
                aic = fit.aic
                aic_values.append(aic)
                bic = fit.bic
                bic_values.append(bic)
    pvalues_table = pd.DataFrame(pvalues_list).T
    pvalues_table.columns = parameters
    criteria = pd.DataFrame(
        np.c_[aic_values, bic_values],
        index=parameters,
        columns=['AIC', 'BIC']
    )
    return pvalues_table.round(3), criteria

#### run ####
if __name__ == '__main__':

    # import data 
    data = pd.read_csv('var_ipc.csv')
    n, _ = data.shape

    # parce date
    data['date'] = pd.to_datetime(data['date'])

    # inputs
    max_p, max_q = 4,4
    series = data['var_ipc']

    # tables
    p_val_table, criteria_table = get_tables(series, max_p, max_q)

    # save tables
    p_val_table.to_csv('p_values_arma.csv')
    criteria_table.to_csv('criteria_arma.csv')